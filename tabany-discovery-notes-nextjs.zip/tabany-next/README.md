# tabany · Discovery Notes

A Next.js app for running discovery interviews and saving them. Fill in an
editable, all-optional questionnaire plus an open-notes box, save it, and revisit
or edit it later. Everything runs in the browser — no AI, no account, no API keys,
no server calls.

## What's inside
- **Interview** — an editable, all-optional questionnaire plus an open-notes box.
  Answers autosave as you type, so a refresh won't lose them.
- **Save** — stores the interview to your log (and lets you edit it later).
- **Saved** — every interview, one card per department.
- **Questions** — edit / add / remove the questions; changes persist.
- **Settings** — export/import a backup of your data.

## Requirements
- Node.js 18.17+ (Node 20 LTS recommended)

## Run it locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Production build
```bash
npm run build
npm run start
```

## Deploy
Push this folder to a GitHub repo and import it at https://vercel.com/new
(no environment variables needed), or run `npm install && npm run build && npm run start`
on any Node host. Because there's no backend or key, it can also be exported as a
fully static site if you prefer (`output: 'export'` in next.config.mjs).

## Where data is stored
Interviews, custom questions and the in-progress draft are saved in the visitor's
browser (localStorage) — per-browser / per-device, not a shared database. Use
**Settings → Export backup** to move data between devices, or to hand a colleague
your questions and saved interviews.

## Project structure
```
app/
  globals.css   styles
  layout.jsx    root layout
  page.jsx      the whole app (client component)
```
